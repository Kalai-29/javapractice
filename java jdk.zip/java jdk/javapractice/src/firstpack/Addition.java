package firstpack;

public class if condition{ 

	public static void main(String[] args) {
		int a=10;
		if(a<15) {
			system.out.println("hello good morning")
		}

	}

}

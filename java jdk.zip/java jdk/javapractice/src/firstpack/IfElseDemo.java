package firstpack;

import java.util.Scanner;

public class IfElseDemo {
	int no,no1,no2,no3;
	Scanner sc=new Scanner(System.in);
	
	void posNeg() {
		System.out.println("Enter the number");
		no=sc.nextInt();
		if (no>0) {
			System.out.println(no+" is a positive number.");
		}
		else {
			System.out.println(no+" is a negative number");
		}
	}

void evenodd() {
	if (no%2==0) {
		System.out.println(no +" is an even number");
	}
	else {
		System.out.println(no +" is an odd number");
	}
}
void max() {
	System.out.println("Enter the number1");
	no1=sc.nextInt();
	System.out.println("Enter the number2");
	no2=sc.nextInt();
	System.out.println("Enter the number3");
	no3=sc.nextInt();
	if (no1>no2 && no1>no3) {
		System.out.println(no1+" is greater ");
	}
	else if(no2>no1 && no2>no3) {
		System.out.println(no2+" is a greater");
	}
	else {
		System.out.println(no3+" is greater");
	}
}
public static void main(String[] args) {
	IfElseDemo ifd=new IfElseDemo();
	ifd.posNeg();
	ifd.evenodd();
	ifd.max();
}

	
	}



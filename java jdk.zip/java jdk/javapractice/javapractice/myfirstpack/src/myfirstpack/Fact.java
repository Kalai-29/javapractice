package myfirstpack;

import java.util.Scanner;

public class Fact {
	public static void main(String[]args) {
		int num;
		double fact=1;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter number");
		num=scanner.nextInt();
		for(int i=num;i>=1;i--) {
			fact=fact*i;
		}
	
		System.out.println("Factorial of "+num+" is "+fact);
		scanner.close();
	}
}
		
	



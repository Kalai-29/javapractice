package myfirstpack;

import java.util.Scanner;

class Armstrong{
	int num, reminder,num1,pow=0;
	double arm=0;
	void inputData() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the number :");
		num = scanner.nextInt();
	}
	
	void calculate() {
		num1 = num;
		while (num !=0) {
			num=num/10;
			pow+=1;
		}
		num = num1;
		
		while (num !=0) {
			reminder = num%10;
			arm = arm +Math.pow(reminder, pow);
			num =num/10;
		}
		
	}
	void print() {
		if(arm == num1) {
			System.out.println("It is a Armstrong number");
		}
		else {
			System.out.println("It is not a Armstrong number");
		}
	}
	
}

public class  ArmstrongEncaps {

	public static void main(String[] args) {
		Armstrong a = new Armstrong();
		a.inputData();
		a.calculate();
		a.print();

	}


		
	}




package myfirstpack;

public class WhileLoopEven {
	public static void main(String[]args) {
		int i=2, sum=0;
		while (i<=100) {
			sum+=i;
			i=i+2;
		}
	System.out.println("The sum of even numbers 1 to 100:"+sum);
	}


	}


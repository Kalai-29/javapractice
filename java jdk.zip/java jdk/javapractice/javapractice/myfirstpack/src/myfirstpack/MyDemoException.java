package myfirstpack;

public class MyDemoException {
	public static void main(String[] args) {
		int a[] ={4,5,3};
		System.out.println("before array access");
		try {
			System.out.println(a[3]);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		System.out.println("after array acess");
		
		}
	}
	
	
		



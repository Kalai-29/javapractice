package myfirstpack;

public class Arrays {
	public static void main(String[] args) {
		
			int a[]= new int [6];
			
			int c[]= {5,3,4,6,8,9};
			
		for(int i=0;i<c.length;i++) {
				System.out.println("c ["+i+ "] ="+c[i]);
				
			
		}
		
	}

}

package myfirstpack;

import java.util.Scanner;

public class ArrayElement {
	public static void main (String[] args) {
		int a[]=new int[5];
		int sum=0;
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter array elements");

		for(int i=0;i<a.length;i++) {
		a[i]=scr.nextInt();
		}

		
		for(int i=0;i<a.length;i++) {
		System.out.println(a[i]);
		}
		for(int i=0;i<a.length;i++) {
			sum=sum+a[i];
			}

			System.out.println("sum of all array elements "+sum);
	}
	
	
	
}


	
		
	



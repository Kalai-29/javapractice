package myfirstpack;
interface One{
	void m1();
}
interface Two{
	void m2();
}




class ImplClass implements One,Two{


	@Override
	public void m2() {
		System.out.println("kalaiyarasi");
		// TODO Auto-generated method stub
		
	}


	@Override
	public void m1() {
		System.out.println("idly");
		// TODO Auto-generated method stub
		
	}
	
}



public class InterMultipleinheritence {
	public static void main(String[] args) {
		System.out.println("baranipriya");
		// TODO Auto-generated method stub


	}


}



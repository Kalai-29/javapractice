
package myfirstpack;

import java.util.Scanner;

class Prime{
	
	int num , m=0, flag =0;
	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number :");
		num = sc.nextInt();
	}
	void calculate() {
		m = num/2;
		if (num == 0||num == 1) {
			System.out.println(num+" is not a Prime Number.");
		}
		else {
			for(int i=2;i<=m;i++) {
				if(num%i == 0) {
					System.out.println(num+" is not a Prime Number");
					flag = 1;
					break;
				}
			}
			if (flag == 0) {
				System.out.println(num+" is a Prime number");
			}
		}
	}
}

public class PrimeNumbers {
	public static void main(String args[]) {
		Prime p = new Prime();
		p.inputData();
		p.calculate();
		
	}

}


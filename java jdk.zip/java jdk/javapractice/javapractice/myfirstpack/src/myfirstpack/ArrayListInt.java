package myfirstpack;

import java.util.ArrayList;

public class ArrayListInt {


		public static void main(String[] args) {
			ArrayList <Integer> subjectmark = new ArrayList <Integer>();
			subjectmark.add(44);
			subjectmark.add(55);
			subjectmark.add(66);
			subjectmark.add(77);
			subjectmark.add(88);
			subjectmark.add(99);
			for(int mark :subjectmark) {
				System.out.println(mark);
			}
		}
				
			}
			
			
	



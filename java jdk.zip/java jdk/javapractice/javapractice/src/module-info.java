/**
 * 
 */
/**
 * 
 */
module javapractice {
}